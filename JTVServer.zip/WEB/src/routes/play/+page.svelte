<script>
	
import { browser } from '$app/environment';
if (browser) {
    window.location.href = '/';
}
</script>
